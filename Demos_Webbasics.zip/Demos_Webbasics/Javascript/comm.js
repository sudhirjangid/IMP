var msg

msg="<h1> Hello Komal </h1>"