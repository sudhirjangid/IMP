﻿using System;
using System.Collections.Generic;
using EntityLibrary;
using ExceptionLibrary;

namespace DataAccessLayerLibrary
{
    public class EmployeeDAL
    {
        public static List<Employee> employeeList = new List<Employee>();


        //Add New Employee
        public static bool RegisterEmployeeDAL(Employee newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                employeeList.Add(newEmployee);
                employeeAdded = true;
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeAdded;
        }
        

        // Get All Employee
        public static List<Employee> GetAllEmployeesDAL()
        {
            return employeeList;
        }



    }
}

