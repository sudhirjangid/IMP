﻿using System;
using System.Collections.Generic;
using BusinessLogicLayerLibrary;
using EntityLibrary;
using ExceptionLibrary;

namespace Employee_Presentation_Layer

{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.Write("Enter your choice :  [ ]\b\b");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        RegisterEmployee();
                        break;
                    case 2:
                        DisplayEmployees();
                        break;
                    case 0:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }       // End of switch case
                Console.ReadKey();
                Console.Clear();
            } while (choice != -1);    //End of dowhile

        }

        // Display
        private static void DisplayEmployees()
        {
            int sal, HRA, TA, DA, PF;
            try
            {
                List<Employee> employeeList = EmployeeBL.GetAllEmployeesBL();
                if (employeeList != null)
                {

                    Console.WriteLine("-----------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("Employee Id| Employee Name\t| Salary | HR\t | TA\t | DA\t | PF\t | Gross_Salary\t | TDS\t | Net_Salary");
                    Console.WriteLine("-----------------------------------------------------------------------------------------------------------------");
                    foreach (Employee employee in employeeList)
                    {
                        sal = Convert.ToInt32(employee.Salary);
                        HRA = Convert.ToInt32(employee.HRA);
                       TA = Convert.ToInt32(employee.TA);
                        DA = Convert.ToInt32(employee.DA);
                        PF = Convert.ToInt32(employee.PF);
                        employee.Gross_salary = sal + HRA + TA + DA;
                        employee.TDS = (sal * 10) / 100;
                        employee.Net_salary = employee.Gross_salary - (PF + employee.TDS);

                        Console.WriteLine("{0,-10} | {1,-10} \t |{2,-5}  | {3,-5}   |  {4,-5} | {5,-5} | {6,-5} | {7,-5} | {8,-5} | {9,-5}", employee.EmployeeId, employee.Name, employee.Salary, employee.HRA, employee.TA, employee.DA, employee.PF, employee.Gross_salary, employee.TDS, employee.Net_salary);
                    }
                    Console.WriteLine("-----------------------------------------------------------------------------------------------------------------");
                }
                else
                {
                    Console.WriteLine("No Customer details are available");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine("\nErrors : \n" + ex.Message);
            }
        }


        private static void RegisterEmployee()
        {
            int sal, HRA, TA, DA, PF;
            try
            {
                Employee newEmployee = new Employee();
                Console.Write("Enter Employee ID : ");
                newEmployee.EmployeeId = Console.ReadLine();

                Console.Write("Enter Employee Name : ");
                newEmployee.Name = Console.ReadLine();
               
                Console.Write("Enter Salary : ");
                newEmployee.Salary = Console.ReadLine();
                sal = Convert.ToInt32(newEmployee.Salary);

                Console.Write("Enter HRA  : ");
                newEmployee.HRA = Console.ReadLine();

                if (newEmployee.HRA == string.Empty)
                {
                    HRA = (sal * 20) / 100;
                    newEmployee.HRA = HRA.ToString();
                }

                Console.Write("Enter TA : ");
                newEmployee.TA = Console.ReadLine();

                if (newEmployee.TA == string.Empty)
                {
                    TA = (sal * 10) / 100;
                    newEmployee.TA = TA.ToString();
                }

                Console.Write("Enter DA  : ");
                newEmployee.DA = Console.ReadLine();

                if (newEmployee.DA == string.Empty)
                {
                    DA = (sal * 50) / 100;
                    newEmployee.DA = DA.ToString();
                }

                Console.Write("Enter PF : ");
                newEmployee.PF = Console.ReadLine();
                if (newEmployee.PF == string.Empty)
                {
                    PF = (sal * 12) / 100;
                    newEmployee.PF = PF.ToString();
                }

             

                bool employeeAdded = EmployeeBL.RegisterEmployeeBL(newEmployee);

                if (employeeAdded)
                    Console.WriteLine($"\n{newEmployee.Name} details " + " are Added");
                else
                    Console.WriteLine("\n Employee Details does not exist");
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine("\nErrors : \n" + ex.Message);
            }

        }

        static void PrintMenu()
        {
            Console.WriteLine("\nMenu :");
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("1: Add Employee");
            Console.WriteLine("2: View Gross salary, TDS, Net Salary of all Employee");
            Console.WriteLine("0: Exit Application");
            Console.WriteLine("-----------------------------------------");

        }


    }
}

