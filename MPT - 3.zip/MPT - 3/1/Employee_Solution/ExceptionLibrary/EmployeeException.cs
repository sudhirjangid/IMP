﻿using System;
namespace ExceptionLibrary
{
    // Step 1 : Derive From ApplicationException class
    public class EmployeeException : ApplicationException
    {
        // Step 2 : Create Parameterized Constructor and pass message to Base class constructor
        public EmployeeException(string message)
            : base(message)
        {

        }
        // default constructor
        public EmployeeException()
        {

        }
    }
}
