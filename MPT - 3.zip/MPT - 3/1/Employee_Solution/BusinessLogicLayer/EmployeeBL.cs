﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using DataAccessLayerLibrary;
using EntityLibrary;
using ExceptionLibrary;

namespace BusinessLogicLayerLibrary
{
    public class EmployeeBL
    {
        public static bool ValidateEmployee(Employee newEmployee)
        {
            StringBuilder builderObj = new StringBuilder();
            bool valid = true;
            try
            {
                // Validation for Employee Id
                if (newEmployee.EmployeeId == string.Empty)
                {
                    builderObj.AppendLine("Employee Id cannot be blank");
                    valid = false;
                }

                // Condition for EmployeeID consists of 6 Digits
                else if (!(Regex.IsMatch(newEmployee.EmployeeId, "[1-9][0-9]{4}")))
                {
                    builderObj.AppendLine("Employee Id  must be of six digits\nEmployee Id cannot not start with 0");
                    valid = false;
                }


                // Validation for Name
               
                if (newEmployee.Name == string.Empty)
                {
                    builderObj.AppendLine("Employee Name cannot be blank");
                    valid = false;
                }


                // Validation for salary
                if (newEmployee.Salary == string.Empty)
                {
                    builderObj.AppendLine("Employee Salary cannot be blank");
                    valid = false;
                }                
                

                if (valid == false)
                {
                    throw new EmployeeException(builderObj.ToString());
                }

            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return valid;
        }


        //Add New Employee
        public static bool RegisterEmployeeBL(Employee newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(newEmployee))
                {
                 
                    employeeAdded = EmployeeDAL.RegisterEmployeeDAL(newEmployee);
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeAdded;
        }


        // Get All Employee
        public static List<Employee> GetAllEmployeesBL()
        {
            List<Employee> employeeList = null;
            try
            {
                employeeList = EmployeeDAL.GetAllEmployeesDAL();

            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeList;
        }


      
    }
}


