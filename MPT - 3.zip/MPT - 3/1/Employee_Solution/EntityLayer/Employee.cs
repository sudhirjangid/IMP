﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLibrary
{
    public class Employee
    {
        //Properties
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public string Salary { get; set; }
        public string HRA { get; set; }
        public string TA { get; set; }
        public string DA { get; set; }
        public string PF { get; set; }
        public int Gross_salary { get; set; }
        public int TDS { get; set; }
        public int Net_salary { get; set; }


        
    }
}
