﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomGenericStack
{
    public class StackException : ApplicationException
    {
        public StackException() : base()
        {
        }

        public StackException(string message) : base(message)
        {
        }
    }
}
