﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1_TypeCompatibility
{
    class Program
    {
        public static void Test(object o)
        {
            Circle c;
            Square s;

            if (o is Circle)
            {
                Console.WriteLine("o is Circle");
                c = (Circle)o;
            }
            else if (o is Square)
            {
                Console.WriteLine("o is Square");
                s = (Square)o;
            }
            else
            {
                Console.WriteLine("o is neither Circle nor Square");
            }
        }
        static void Main(string[] args)
        {
            //Circle c = new Circle(10);
            //object obj = c;
            //int num = (int)obj;     //It compiles, but throws Exception => System.InvalidCastException: 'Specified cast is not valid.'

            Circle c = new Circle(10);
            Square s = new Square(15);

            Test(c);
            Test(s);
            Test("Passing string value instead of Circle or Square");

            Console.ReadKey();
        }
    }
}
