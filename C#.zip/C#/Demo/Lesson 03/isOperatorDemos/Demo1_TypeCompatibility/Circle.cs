﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1_TypeCompatibility
{
    class Circle
    {
        int radius;

        public Circle(int r)
        {
            radius = r;
        }
    }
}
