﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1_TypeCompatibility
{
    class Square
    {
        int length;

        public Square(int l)
        {
            length = l;
        }
    }
}
