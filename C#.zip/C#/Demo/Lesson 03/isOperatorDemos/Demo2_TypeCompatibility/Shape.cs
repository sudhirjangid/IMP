﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2_TypeCompatibility
{
    class Shape : IFormatProvider
    {
        public object GetFormat(Type formatType)
        {
            if (formatType.Equals(this.GetType()))
                return this;

            return null;
        }
    }
}
