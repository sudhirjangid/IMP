﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2_TypeCompatibility
{
    class Program
    {
        static void Main(string[] args)
        {
            var s = new Shape();
            Console.WriteLine($"s is IFormatProvider : {(s is IFormatProvider)}");
            Console.WriteLine($"s is Object : {(s is Object)}");
            Console.WriteLine($"s is Shape : {(s is Shape)}");
            Console.WriteLine($"s is Circle : {(s is Circle)}");
            Console.WriteLine();

            var c = new Circle();
            Console.WriteLine($"c is IFormatProvider : {(c is IFormatProvider)}");
            Console.WriteLine($"c is Object : {(c is Object)}");
            Console.WriteLine($"c is Shape : {(c is Shape)}");
            Console.WriteLine($"c is Circle : {(c is Circle)}");
            Console.WriteLine();

            Shape sc = new Circle();
            Console.WriteLine($"sc is IFormatProvider : {(sc is IFormatProvider)}");
            Console.WriteLine($"sc is Object : {(sc is Object)}");
            Console.WriteLine($"sc is Shape : {(sc is Shape)}");
            Console.WriteLine($"sc is Circle : {(sc is Circle)}");
            Console.WriteLine();

            Console.WriteLine($"3 is int : {(3 is int)}");                          //Compiler will generate the warning for this
            Console.WriteLine();

            int number = 72;
            Console.WriteLine($"number is long : {(number is long)}");              //Compiler will generate the warning for this
            Console.WriteLine($"number is double : {(number is double)}");          //Compiler will generate the warning for this
            Console.WriteLine($"number is object : {(number is object)}");          //Compiler will generate the warning for this
            Console.WriteLine($"number is ValueType : {(number is ValueType)}");    //Compiler will generate the warning for this
            Console.WriteLine($"number is int : {(number is int)}");                //Compiler will generate the warning for this

            Console.ReadKey();
        }
    }
}
