﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo4_ConstantPattern
{
    class Dice
    {
        Random rnd = new Random();

        public int Roll()
        {
            return rnd.Next(1, 6);
        }
    }
}
