﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo4_ConstantPattern
{
    class Program
    {
        public static void ShowDiceValue(object o)
        {
            const int HIGH_ROLL = 6;

            if (o is Dice d)
            {
                if (d.Roll() is HIGH_ROLL)
                    Console.WriteLine($"The dice roll value is {HIGH_ROLL}!");
                else
                    Console.WriteLine($"The dice roll value is not {HIGH_ROLL}!");
            }
        }
        static void Main(string[] args)
        {
            Dice d1 = new Dice();
            ShowDiceValue(d1);

            Console.ReadKey();
        }
    }
}
