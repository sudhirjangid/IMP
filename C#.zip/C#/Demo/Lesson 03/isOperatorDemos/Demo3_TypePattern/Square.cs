﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3_TypePattern
{
    class Square
    {
        public int Length { get; set; }

        public Square(int l)
        {
            Length = l;
        }
    }
}
