﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3_TypePattern
{
    class Program
    {
        public static void ShowValue(object o)
        {
            if (o is Circle c)
                Console.WriteLine($"Circle Radius is : {c.Radius}");
            else if (o is Square s)
                Console.WriteLine($"Square Length is : {s.Length}");
        }
        static void Main(string[] args)
        {
            Object o = new Circle(10);
            ShowValue(o);

            o = new Square(15);
            ShowValue(o);

            Console.ReadKey();
        }
    }
}
