﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo6_VarPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            object[] items = { new Circle(10), new Square(15) };

            foreach (var item in items)
            {
                if (item is var obj)
                    Console.WriteLine($"Type : {obj.GetType().Name} \t Value : {obj}");
            }

            Console.ReadKey();
        }
    }
}
