﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo6_VarPattern
{
    class Circle
    {
        public int Radius { get; set; }

        public Circle(int r)
        {
            Radius = r;
        }

        public override string ToString()
        {
            return Radius.ToString();
        }
    }
}
