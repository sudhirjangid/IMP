﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo6_VarPattern
{
    class Square
    {
        public int Length { get; set; }

        public Square(int l)
        {
            Length = l;
        }

        public override string ToString()
        {
            return Length.ToString();
        }
    }
}
