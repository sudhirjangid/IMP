﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo5_ConstantPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            object obj = null;

            if (obj is null)
            {
                Console.WriteLine("obj does not have a value");
            }
            else
            {
                Console.WriteLine($"obj is : {obj}");
            }

            int? num = 10;
            if (num is null)
            {
                Console.WriteLine("num does not have a value");
            }
            else
            {
                Console.WriteLine($"num is : {num.Value}");
            }

            Console.ReadKey();
        }
    }
}
