﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1_StringClass
{
    class Program
    {
        static void Main(string[] args)
        {
            //Assigning the string literal to String variable
            string firstName = "Robert";
            string lastName = "Desouza";

            //Creating String by using concatenation (+) operator
            string fullName = firstName + lastName;
            Console.WriteLine($"Full Name : {fullName}");

            //Creating String from character array
            char[] letters = { 'H', 'e', 'l', 'l', 'o' };

            //Creating String by using constructor
            string greetings = new string(letters);
            Console.WriteLine($"Greetings : {greetings}");

            //Creating String by retrieving a property or calling a method that returns a string
            string[] sarray = { "Welcome", ".NET", "Batch" };
            string message = String.Join(" ", sarray);
            Console.WriteLine($"Message : {message}");

            //Creating String by calling a formatting method to convert a value or an object to its string representation
            DateTime waiting = new DateTime(2019, 1, 17, 10, 03, 43);
            string chat = String.Format("Message Sent at {0:t} on {0:D}", waiting);
            Console.WriteLine($"Message : {chat}");

            Console.WriteLine($"Number of Characters in '{message}' are : {message.Length}");

            string str1 = "This is test";
            string str2 = "This is text";

            if (String.Compare(str1, str2) == 0)
            {
                Console.WriteLine($"'{str1}' and '{str2}' are equal");
            }
            else
            {
                Console.WriteLine($"'{str1}' and '{str2}' are not equal");
            }

            Console.WriteLine($"String.Concat(C, Sharp, Training) => {String.Concat("C", "Sharp", "Training")}");

            Console.WriteLine($"'{message}' contains 'come' => {message.Contains("come")}");

            Console.WriteLine($"'{message}' ends with 'tch' => {message.EndsWith("tch")}");

            Console.WriteLine($"Index of 'N' is {message.IndexOf("N")} in {message}");

            Console.WriteLine($"Inserting 'to' at index 8 in {message} => {message.Insert(8, "to ")}");

            Console.WriteLine($"String.IsNullOrEmpty('{message}') => {String.IsNullOrEmpty(message)}");
            Console.WriteLine($"String.IsNullOrEmpty(null) => {String.IsNullOrEmpty(null)}");
            Console.WriteLine($"String.IsNullOrEmpty(String.Empty) => {String.IsNullOrEmpty(String.Empty)}");

            Console.WriteLine($"Last Index of 'c' in '{message}' => {message.LastIndexOf("c")}");

            Console.WriteLine($"Replace 'Welcome' in '{message}' by 'Hello' => {message.Replace("Welcome", "Hello")}");

            Console.WriteLine($"Substring of '{message}' from index 6 => {message.Substring(6)}");
            Console.WriteLine($"Substring of '{message}' from index 6 and 5 characters only => {message.Substring(6,5)}");

            Console.WriteLine($"Lower case characters => {message.ToLower()}");
            Console.WriteLine($"Upper case characters => {message.ToUpper()}");

            Console.ReadKey();
        }
    }
}
