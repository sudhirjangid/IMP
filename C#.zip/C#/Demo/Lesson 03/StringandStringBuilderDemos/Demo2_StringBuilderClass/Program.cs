﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2_StringBuilderClass
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder message = new StringBuilder("Hello");

            Console.WriteLine($"Message => {message}");
            Console.WriteLine($"message.Append('.NET Batch') => {message.Append(".NET Batch")}");
            Console.WriteLine($"message.AppendLine('C Sharp Training') => {message.AppendLine("C Sharp Training")}");
            Console.WriteLine($"message.AppendFormat('Message at 0:t on 0:D', DateTime.Now) => {message.AppendFormat("Message at {0:t} on {0:D}", DateTime.Now)}");
            Console.WriteLine($"message.Insert(5, ' to ') => {message.Insert(5, " to ")}");
            Console.WriteLine($"message.Remove(6,3) => {message.Remove(6, 3)}");
                        
            Console.ReadKey();
        }
    }
}
