﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equals_EqualToDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            num1 = 10;
            num2 = 10;
            Console.WriteLine($"10 == 10 => {num1 == num2}");
            Console.WriteLine($"10.Equals(10) => {num1.Equals(num2)}");
            Console.WriteLine();

            Customer custObj = new Customer() { Name = "Robert" };
            Customer custObj1 = new Customer() { Name = "Robert" };
            Console.WriteLine($"custObj == custObj1 => {custObj == custObj1}");
            Console.WriteLine($"custObj.Equals(custObj1) => {custObj.Equals(custObj1)}");
            Console.WriteLine();

            object str = ".NET";
            object str1 = ".NET";
            Console.WriteLine($"str == str1 => {str == str1}");
            Console.WriteLine($"str.Equals(str1) => {str.Equals(str1)}");
            Console.WriteLine();

            object teststr = new String(new char[] { 't', 'e', 's', 't' });
            object teststr1 = new String(new char[] { 't', 'e', 's', 't' });
            Console.WriteLine($"teststr == teststr1 => {teststr == teststr1}");
            Console.WriteLine($"teststr.Equals(teststr1) => {teststr.Equals(teststr1)}");
            Console.WriteLine();

            object nullstr = null;
            object nullstr1 = null;
            Console.WriteLine($"nullstr == nullstr1 => {nullstr == nullstr1}");
            Console.WriteLine($"nullstr.Equals(nullstr1) => {nullstr.Equals(nullstr1)}"); //Exception
            Console.WriteLine();

            Console.ReadKey();
        }
    }
}
