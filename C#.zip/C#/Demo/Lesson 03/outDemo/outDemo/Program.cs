﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace outDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle c = new Circle();

            Console.Write("Enter Radius : ");
            c.Radius = Convert.ToInt32(Console.ReadLine());

            double area, circumference;

            c.CircleOperations(out area, out circumference);

            Console.WriteLine($"Area of Circle is : {area}");
            Console.WriteLine($"Circumference of Circle is : {circumference}");

            Console.ReadKey();
        }
    }
}
