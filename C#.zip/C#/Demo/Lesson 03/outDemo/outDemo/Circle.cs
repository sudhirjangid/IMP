﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace outDemo
{
    class Circle
    {
        public int Radius { get; set; }

        public void CircleOperations(out double area, out double circumference)
        {
            area = Math.PI * Radius * Radius;
            circumference = 2 * Math.PI * Radius;
        }
    }
}
