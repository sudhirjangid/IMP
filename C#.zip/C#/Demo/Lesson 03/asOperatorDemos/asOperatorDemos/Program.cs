﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asOperatorDemos
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle c = new Circle();

            Shape s = c as Shape;

            if (s != null)
            {
                Console.WriteLine(s);
            }

            Console.WriteLine();

            object[] items = new object[6];
            items[0] = new Shape();
            items[1] = new Circle();
            items[2] = ".NET";
            items[3] = 123;
            items[4] = 123.45;
            items[5] = null;

            for (int i = 0; i < items.Length; i++)
            {
                string str = items[i] as string;

                Console.Write($"Index {i} : ");

                if (str != null)
                {
                    Console.Write($"'{str}'");
                }
                else
                {
                    Console.Write("Not a String");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
