﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1_ParameterPassing
{
    class Program
    {
        public void Cube(ref int num)
        {
            num = num * num * num;
        }
        static void Main(string[] args)
        {
            Program prg = new Program();
            int num = 5;

            Console.WriteLine($"Value of number before calling Cube Method : {num}");
            prg.Cube(ref num);
            Console.WriteLine($"Value of number after calling Cube Method : {num}");

            Console.ReadKey();
        }
    }
}
