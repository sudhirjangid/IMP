﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2_ReturnValues
{
    class CategoryCollection
    {
        Category[] categories = {
            new Category(){ CategoryID=101, CategoryName="Accessories"},
            new Category(){ CategoryID=102, CategoryName="Stationary"},
            new Category(){ CategoryID=103, CategoryName="Electronics"}
        };

        Category nocategory = null;

        public ref Category GetCategoryByName(string name)
        {
            for (int i = 0; i < categories.Length; i++)
            {
                if (name == categories[i].CategoryName)
                    return ref categories[i];
            }

            return ref nocategory;
        }

        public void ListCategories()
        {
            foreach (var category in categories)
            {
                Console.WriteLine($"{category.CategoryName} has Category ID {category.CategoryID}");
            }
            Console.WriteLine();
        }
    }
}
