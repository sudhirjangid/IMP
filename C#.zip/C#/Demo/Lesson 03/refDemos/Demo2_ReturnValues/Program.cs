﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2_ReturnValues
{
    class Program
    {
        static void Main(string[] args)
        {
            var categoryList = new CategoryCollection();
            categoryList.ListCategories();

            ref var category = ref categoryList.GetCategoryByName("Electronics");

            if (category != null)
            {
                category = new Category() { CategoryID = 104, CategoryName = "Toys" };
            }
            categoryList.ListCategories();

            Console.ReadKey();
        }
    }
}
