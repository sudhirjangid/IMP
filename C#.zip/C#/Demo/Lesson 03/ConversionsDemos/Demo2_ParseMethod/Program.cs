﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2_ParseMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine($"int.Parse(\"12345\") => {int.Parse("12345")}");
                Console.WriteLine($"int.Parse(\" 12345\") => {int.Parse(" 12345")}");
                Console.WriteLine($"int.Parse(\" 12345 \") => {int.Parse(" 12345 ")}");
                Console.WriteLine($"int.Parse(\"12345 \") => {int.Parse("12345 ")}");
                Console.WriteLine($"float.Parse(\"45.678\") => {float.Parse("45.678")}");
                Console.WriteLine($"float.Parse(Math.PI.ToString()) => {float.Parse(Math.PI.ToString())}");
                Console.WriteLine($"int.Parse(null) => {int.Parse(null)}");                     //ArgumentNullException
                Console.WriteLine($"int.Parse(\"45.678\") => {int.Parse("45.678")}");           //FormatException
                Console.WriteLine($"int.Parse(\"12 345\") => {int.Parse("12 345")}");           //FormatException
                Console.WriteLine($"short.Parse(\"1234567\") => {short.Parse("1234567")}");     //OverflowException
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (OverflowException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
