﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3_TryParseMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            short snum;
            float fnum;

            try
            {
                Console.WriteLine($"int.TryParse(\"12345\", out num) => {int.TryParse("12345", out num)}");
                Console.WriteLine($"int.TryParse(\" 12345\", out num) => {int.TryParse(" 12345", out num)}");
                Console.WriteLine($"int.TryParse(\" 12345 \", out num) => {int.TryParse(" 12345 ", out num)}");
                Console.WriteLine($"int.TryParse(\"12345 \", out num) => {int.TryParse("12345 ", out num)}");
                Console.WriteLine($"float.TryParse(\"45.678\", out fnum) => {float.TryParse("45.678", out fnum)}");
                Console.WriteLine($"float.TryParse(Math.PI.ToString(), out fnum) => {float.TryParse(Math.PI.ToString(), out fnum)}");
                Console.WriteLine($"int.TryParse(null, out num) => {int.TryParse(null, out num)}");
                Console.WriteLine($"int.TryParse(\"45.678\", out num) => {int.TryParse("45.678", out num)}");
                Console.WriteLine($"int.TryParse(\"12 345\", out num) => {int.TryParse("12 345", out num)}");    
                Console.WriteLine($"short.TryParse(\"1234567\", out snum) => {short.TryParse("1234567", out snum)}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (OverflowException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
