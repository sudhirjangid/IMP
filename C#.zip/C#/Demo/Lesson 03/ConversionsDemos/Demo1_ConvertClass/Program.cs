﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1_ConvertClass
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine($"Convert.ToInt32(34.89) => {Convert.ToInt32(34.89)}");
                Console.WriteLine($"Convert.ToInt32(\"12345\") => {Convert.ToInt32("12345")}");
                Console.WriteLine($"Convert.ToInt32(\" 455\") => {Convert.ToInt32(" 455")}");
                Console.WriteLine($"Convert.ToInt32(\"678 \") => {Convert.ToInt32("678 ")}");
                Console.WriteLine($"Convert.ToDateTime('10/23/2018') => {Convert.ToDateTime("10/23/2018")}");
                Console.WriteLine($"Convert.ToBoolean(23) => {Convert.ToBoolean(23)}");
                Console.WriteLine($"Convert.ToInt32(null) => {Convert.ToInt32(null)}");
                Console.WriteLine($"Convert.ToString(null) => {Convert.ToString(null)}");
                Console.WriteLine($"Convert.ToChar(\"C\") => {Convert.ToChar("C")}");
                Console.WriteLine($"Convert.ToChar(\"C Sharp\") => {Convert.ToChar("C Sharp")}");       //FormatException
                Console.WriteLine($"Convert.ToChar(null) => {Convert.ToChar(null)}");                   //ArgumentNullException
                Console.WriteLine($"Convert.ToInt32(\"4  6\") => {Convert.ToInt32("4  6")}");           //FormatException
                Console.WriteLine($"Convert.ToBoolean('batch') => {Convert.ToBoolean("batch")}");       //FormatException
                Console.WriteLine($"Convert.ToDateTime(20181010) => {Convert.ToDateTime(20181010)}");   //InvalidCastException
                Console.WriteLine($"Convert.ToByte(10000) => {Convert.ToByte(10000)}");                 //OverflowException
                
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (InvalidCastException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (OverflowException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
