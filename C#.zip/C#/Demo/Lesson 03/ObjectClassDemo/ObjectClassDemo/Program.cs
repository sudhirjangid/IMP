﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectClassDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Construct a Point object
            Point p1 = new Point(1, 2);

            //Make another Point object that is a copy of the first
            Point p2 = p1.Copy();

            //Make another variable that references the first Point object
            Point p3 = p1;

            //Below line will display false because p1 and p2 refer to two different objects
            Console.WriteLine($"Object.ReferenceEquals(p1, p2) => {Object.ReferenceEquals(p1, p2)}");

            //Below line will display true because p1 and p2 refer to two different objects that have same value
            Console.WriteLine($"Object.Equals(p1, p2) => {Object.Equals(p1, p2)}");

            //Below line will display true because p1 and p3 refer to same object
            Console.WriteLine($"Object.ReferenceEquals(p1, p3) => {Object.ReferenceEquals(p1, p3)}");

            //Below line will display : p1's value is => (1, 2)
            Console.WriteLine($"p1's value is => {p1.ToString()}");

            Console.ReadKey();
        }
    }
}
