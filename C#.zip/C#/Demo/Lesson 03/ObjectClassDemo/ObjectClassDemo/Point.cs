﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectClassDemo
{
    class Point
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }

        public override bool Equals(object obj)
        {
            //If current object and obj do not refer to the same type, they are not equal
            if (obj.GetType() != this.GetType())
                return false;

            //Return true if X and Y fields match
            Point other = (Point)obj;
            return (this.X == other.X) && (this.Y == other.Y);
        }

        //Returns XOR of the X and Y fields
        public override int GetHashCode()
        {
            return X ^ Y;
        }

        //Returns the point's value as a string
        public override string ToString()
        {
            return String.Format($"({X}, {Y})");
        }

        //Returns a copy of the current point object by making a simple field copy
        public Point Copy()
        {
            return (Point)this.MemberwiseClone();
        }
    }
}
